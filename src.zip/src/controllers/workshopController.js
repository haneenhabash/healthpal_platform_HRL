const { Workshop, Registration } = require('../models');
const { Op } = require('sequelize');

// POST /api/workshops
exports.createWorkshop = async (req, res) => {
  try {
    const workshop = await Workshop.create(req.body);
    return res
      .status(201)
      .json({ message: 'Workshop created successfully', workshop });
  } catch (error) {
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({
        message: 'Validation error',
        errors: error.errors.map(e => e.message)
      });
    }

    return res
      .status(500)
      .json({ message: 'Error creating workshop', error: error.message });
  }
};

// GET /api/workshops  (list + filters)
exports.getAllWorkshops = async (req, res) => {
  try {
    const { category, language, status, date } = req.query;
    const where = {};

    if (category) where.category = category;
    if (language) where.language = language;
    if (status) where.status = status;
    if (date) where.date = { [Op.gte]: new Date(date) };

    const workshops = await Workshop.findAll({
      where,
      order: [['date', 'ASC']],
      include: [{ model: Registration }]
    });

    return res.json(workshops);
  } catch (error) {
    return res
      .status(500)
      .json({ message: 'Error fetching workshops', error: error.message });
  }
};

// GET /api/workshops/:id
exports.getWorkshopById = async (req, res) => {
  try {
    const workshop = await Workshop.findByPk(req.params.id, {
      include: [{ model: Registration }]
    });

    if (!workshop) {
      return res.status(404).json({ message: 'Workshop not found' });
    }

    return res.json(workshop);
  } catch (error) {
    return res
      .status(500)
      .json({ message: 'Error fetching workshop', error: error.message });
  }
};

// PUT /api/workshops/:id
exports.updateWorkshop = async (req, res) => {
  try {
    const workshop = await Workshop.findByPk(req.params.id);
    if (!workshop) {
      return res.status(404).json({ message: 'Workshop not found' });
    }

    await workshop.update(req.body);

    return res.json({ message: 'Workshop updated successfully', workshop });
  } catch (error) {
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({
        message: 'Validation error',
        errors: error.errors.map(e => e.message)
      });
    }

    return res
      .status(500)
      .json({ message: 'Error updating workshop', error: error.message });
  }
};

// DELETE /api/workshops/:id
exports.deleteWorkshop = async (req, res) => {
  try {
    const workshop = await Workshop.findByPk(req.params.id);
    if (!workshop) {
      return res.status(404).json({ message: 'Workshop not found' });
    }

    await workshop.destroy();
    return res.json({ message: 'Workshop deleted successfully' });
  } catch (error) {
    return res
      .status(500)
      .json({ message: 'Error deleting workshop', error: error.message });
  }
};

// GET /api/workshops/:id/attendees
exports.getAttendees = async (req, res) => {
  try {
    const workshop = await Workshop.findByPk(req.params.id, {
      include: [{ model: Registration }]
    });

    if (!workshop) {
      return res.status(404).json({ message: 'Workshop not found' });
    }

    return res.json(workshop.Registrations);
  } catch (error) {
    return res
      .status(500)
      .json({ message: 'Error fetching attendees', error: error.message });
  }
};
