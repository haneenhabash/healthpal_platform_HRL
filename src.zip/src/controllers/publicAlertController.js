const { PublicAlert } = require('../models');
const { Op } = require('sequelize');

// POST /api/alerts
exports.createAlert = async (req, res) => {
  try {
    const alert = await PublicAlert.create(req.body);
    return res
      .status(201)
      .json({ message: 'Public health alert created successfully', alert });
  } catch (error) {
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({
        message: 'Validation error',
        errors: error.errors.map((e) => e.message)
      });
    }

    return res
      .status(500)
      .json({ message: 'Error creating alert', error: error.message });
  }
};

exports.searchAlerts = async (req, res) => {
  try {
    const { type, region, status, severity, title } = req.query;
    const where = {};

    if (title) where.title = { [Op.like]: `%${title}%` };
    if (type) where.type = type;
    if (region) where.region = region;
    if (status) where.status = status;
    if (severity) where.severity = severity;

    const alerts = await PublicAlert.findAll({
      where,
      order: [['createdAt', 'DESC']]
    });

    return res.json(alerts);
  } catch (error) {
    return res
      .status(500)
      .json({ message: 'Error searching alerts', error: error.message });
  }
};

exports.getAlertById = async (req, res) => {
  try {
    const alert = await PublicAlert.findByPk(req.params.id);
    if (!alert) {
      return res.status(404).json({ message: 'Alert not found' });
    }
    return res.json(alert);
  } catch (error) {
    return res
      .status(500)
      .json({ message: 'Error fetching alert', error: error.message });
  }
};

exports.updateAlert = async (req, res) => {
  try {
    const alert = await PublicAlert.findByPk(req.params.id);
    if (!alert) {
      return res.status(404).json({ message: 'Alert not found' });
    }

    await alert.update(req.body);

    return res.json({
      message: 'Public health alert updated successfully',
      alert
    });
  } catch (error) {
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({
        message: 'Validation error',
        errors: error.errors.map((e) => e.message)
      });
    }

    return res
      .status(500)
      .json({ message: 'Error updating alert', error: error.message });
  }
};

exports.deleteAlert = async (req, res) => {
  try {
    const alert = await PublicAlert.findByPk(req.params.id);
    if (!alert) {
      return res.status(404).json({ message: 'Alert not found' });
    }
    await alert.destroy();
    return res.json({ message: 'Public health alert deleted successfully' });
  } catch (error) {
    return res
      .status(500)
      .json({ message: 'Error deleting alert', error: error.message });
  }
};
