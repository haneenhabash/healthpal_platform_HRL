const API_BASE_URL = "http://localhost:3000"; // عدلي لو البورت مختلف

let token = localStorage.getItem("token") || null;

// DOM elements
const loginSection = document.getElementById("login-section");
const appSection = document.getElementById("app-section");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");
const resultContainer = document.getElementById("result-container");
const resultMeta = document.getElementById("result-meta");
const resultStatusPill = document.getElementById("result-status-pill");
const actionsDiv = document.getElementById("actions");
const topRightArea = document.getElementById("top-right-area");

const STATUS_MESSAGES = {
  200: "OK – Request succeeded.",
  201: "Created – Resource has been created.",
  204: "No Content – Request successful with no body.",
  400: "Bad Request – Check your data.",
  401: "Unauthorized – Token missing or invalid.",
  403: "Forbidden – You don't have permission.",
  404: "Not Found – Endpoint doesn't exist.",
  500: "Server Error – Check your backend logs."
};

// ---------- Helpers for API ----------

async function apiRequest(endpoint, { method = "GET", body = null } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(API_BASE_URL + endpoint, {
    method,
    headers,
    body: body ? JSON.stringify(body) : null
  });

  const contentType = res.headers.get("content-type") || "";
  let parsedBody;

  if (contentType.includes("application/json")) {
    parsedBody = await res.json();
  } else {
    parsedBody = await res.text();
  }

  if (!res.ok) {
    throw { status: res.status, body: parsedBody, endpoint };
  }

  return { status: res.status, body: parsedBody, endpoint };
}

// ---------- UI helpers ----------

function updateUI() {
  if (token) {
    loginSection.style.display = "none";
    appSection.style.display = "block";

    topRightArea.innerHTML = `
      <span class="pill" style="margin-right: 8px;" id="welcome-text">
        Logged in ✓
      </span>
      <button id="logout-btn" class="btn btn-outline">Logout</button>
    `;

    document.getElementById("logout-btn").addEventListener("click", handleLogout);
    fetchCurrentUserSummary();
  } else {
    loginSection.style.display = "block";
    appSection.style.display = "none";
    topRightArea.innerHTML = `<span class="pill">Not logged in</span>`;
  }
}

function setStatus(type, status) {
  const isSuccess = type === "success";

  if (status) {
    resultStatusPill.textContent = `${isSuccess ? "Success" : "Error"} • ${status}`;
  } else {
    resultStatusPill.textContent = isSuccess ? "Success" : "Error";
  }

  resultStatusPill.style.background = isSuccess
    ? "rgba(220,252,231,0.9)"
    : "rgba(254,226,226,0.9)";
  resultStatusPill.style.borderColor = isSuccess
    ? "rgba(22,163,74,0.4)"
    : "rgba(220,38,38,0.4)";
  resultStatusPill.style.color = isSuccess ? "#15803d" : "#b91c1c";

  const msg =
    (status && STATUS_MESSAGES[status]) ||
    (status ? `HTTP ${status}` : "");

  resultMeta.style.display = "flex";
  resultMeta.innerHTML = `
    <span class="badge ${isSuccess ? "badge-success" : "badge-error"}">
      ${isSuccess ? "Success" : "Error"}
    </span>
    <span>${msg}</span>
  `;
}

// create accordion section
function createSection(title, innerHTML, { open = true } = {}) {
  const section = document.createElement("div");
  section.className = "section";

  const header = document.createElement("div");
  header.className = "section-header";

  const titleEl = document.createElement("div");
  titleEl.className = "section-title";
  titleEl.textContent = title;

  const toggle = document.createElement("div");
  toggle.className = "section-toggle";
  toggle.textContent = open ? "▾" : "▸";

  const body = document.createElement("div");
  body.className = "section-body";
  body.innerHTML = innerHTML;
  if (!open) body.classList.add("collapsed");

  header.addEventListener("click", () => {
    const collapsed = body.classList.toggle("collapsed");
    toggle.textContent = collapsed ? "▸" : "▾";
  });

  header.appendChild(titleEl);
  header.appendChild(toggle);
  section.appendChild(header);
  section.appendChild(body);

  return section;
}

// key-value list html
function buildKvList(obj) {
  let html = '<div class="kv-list">';
  Object.entries(obj).forEach(([k, v]) => {
    if (v === null || v === undefined) return;
    html += `<div class="kv-key">${k}</div><div class="kv-value">${formatValue(
      v
    )}</div>`;
  });
  html += "</div>";
  return html;
}

function formatValue(v) {
  if (Array.isArray(v)) {
    return `<pre>${JSON.stringify(v, null, 2)}</pre>`;
  }

  if (typeof v === "object" && v !== null) {
    return `<pre>${JSON.stringify(v, null, 2)}</pre>`;
  }

  return String(v);
}


// main renderer
function renderFriendly(endpoint, body) {
  resultContainer.innerHTML = "";

  // نص فقط
  if (typeof body === "string") {
    const p = document.createElement("div");
    p.className = "simple-text";
    p.textContent = body;
    resultContainer.appendChild(p);
    return;
  }

  // Array => قائمة عناصر
  if (Array.isArray(body)) {
    if (body.length === 0) {
      resultContainer.innerHTML =
        '<p class="result-empty">No items found.</p>';
      return;
    }

    const info = document.createElement("p");
    info.className = "result-empty";
    info.textContent = `Found ${body.length} item(s). Click to expand each one.`;
    resultContainer.appendChild(info);

    body.forEach((item, idx) => {
      const section = createSection(
        `Item #${idx + 1}`,
        buildKvList(item),
        { open: idx === 0 }
      );
      resultContainer.appendChild(section);
    });

    return;
  }


  if (body.dashboard && body.dashboard.stats && body.dashboard.links) {
    const stats = body.dashboard.stats;
    const links = body.dashboard.links;

    const statsCards = document.createElement("div");
    statsCards.className = "cards-grid";

    Object.entries(stats).forEach(([key, value]) => {
      const card = document.createElement("div");
      card.className = "mini-card";
      card.innerHTML = `
        <div class="mini-card-title">${key}</div>
        <div class="mini-card-value">${value}</div>
      `;
      statsCards.appendChild(card);
    });

    const linksHtml = `
      <div class="kv-list">
        ${Object.entries(links)
          .map(
            ([k, v]) =>
              `<div class="kv-key">${k}</div><div class="kv-value">${v}</div>`
          )
          .join("")}
      </div>
    `;

    const statsSection = createSection("Statistics", statsCards.outerHTML || statsCards.innerHTML, {
      open: true
    });
    const linksSection = createSection("API Links", linksHtml, { open: false });

    resultContainer.appendChild(statsSection);
    resultContainer.appendChild(linksSection);
    return;
  }

  // 2) /api/users/me أو أي object فيه email/role => User Profile
  if (body.email && body.role) {
    const basicInfo = {
      id: body.id,
      email: body.email,
      role: body.role,
      name: body.name || body.fullName || undefined
    };

    const profileSection = createSection(
      "User Profile",
      buildKvList(basicInfo),
      { open: true }
    );

    // باقي الخصائص كـ "extra details"
    const extra = { ...body };
    delete extra.id;
    delete extra.email;
    delete extra.role;
    delete extra.name;
    delete extra.fullName;

    resultContainer.appendChild(profileSection);

    if (Object.keys(extra).length > 0) {
      const extraSection = createSection(
        "Extra Details",
        buildKvList(extra),
        { open: false }
      );
      resultContainer.appendChild(extraSection);
    }

    return;
  }

  // 3) أي object عادي => key/value + إمكانية إخفاء/إظهار
  const section = createSection("Details", buildKvList(body), { open: true });
  resultContainer.appendChild(section);
}

// ---------- Login & actions ----------

updateUI();

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.textContent = "";
  resultMeta.style.display = "none";
  resultContainer.innerHTML =
    '<p class="result-empty">Logging in...</p>';

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  try {
    const { status, body } = await apiRequest("/api/auth/login", {
      method: "POST",
      body: { email, password }
    });

    const data = typeof body === "string" ? {} : body;
    const receivedToken = data.token || data.accessToken;

    if (!receivedToken) {
      throw { status: 500, body: { message: "Token field not found in response." } };
    }

    token = receivedToken;
    localStorage.setItem("token", token);

    updateUI();
    setStatus("success", status);
    resultContainer.innerHTML =
      '<p class="result-empty">Login successful. You can now use the buttons on the left.</p>';
  } catch (err) {
    console.error(err);
    loginError.textContent =
      (err.body && err.body.message) ||
      (typeof err.body === "string" ? err.body : "Login failed. Please check credentials.");
    setStatus("error", err.status || 0);
    renderFriendly(err.endpoint || "", err.body || "Login failed.");
  }
});

function handleLogout() {
  token = null;
  localStorage.removeItem("token");
  updateUI();
  resultMeta.style.display = "none";
  resultStatusPill.textContent = "No request yet";
  resultContainer.innerHTML =
    '<p class="result-empty">Logged out. Please log in again to test protected endpoints.</p>';
}

async function fetchCurrentUserSummary() {
  try {
    const { body } = await apiRequest("/api/users/me", { method: "GET" });
    const welcomeText = document.getElementById("welcome-text");
    if (!welcomeText) return;

    if (body && typeof body === "object") {
      const email = body.email || "Unknown";
      const role = body.role || "";
      welcomeText.textContent = role
        ? `Logged in as ${email} (${role})`
        : `Logged in as ${email}`;
    }
  } catch {
    // لا شيء
  }
}

actionsDiv.addEventListener("click", async (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;

  const endpoint = btn.getAttribute("data-endpoint");
  const method = btn.getAttribute("data-method") || "GET";
  if (!endpoint) return;

  resultMeta.style.display = "none";
  resultStatusPill.textContent = "Requesting...";
  resultContainer.innerHTML =
    '<p class="result-empty loading">Loading...</p>';

  try {
    const { status, body } = await apiRequest(endpoint, { method });
    setStatus("success", status);
    renderFriendly(endpoint, body);
  } catch (err) {
    console.error(err);
    setStatus("error", err.status || 0);
    renderFriendly(err.endpoint || endpoint, err.body);
  }
});
